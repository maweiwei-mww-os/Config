# Verification - 0.2.0

Date: 2026-10-09. These are observed results, not a platform-wide performance guarantee.

| Check | Result |
| --- | --- |
| Independent .NET 8 framework suite | 19 passed |
| Existing consumer regression suite | 28 passed |
| Install tgz into a separate Unity project | Passed |
| Unity 2022.3.60f1c1 Editor, Mono | Passed |
| Generated API, reference traversal, struct iteration and snapshot capture | 200,000 iterations, 0 GC.Alloc events in the Editor probe |
| Allocation positive/empty controls | 1 event for a 4 KB array; 0 events for empty action |
| Windows x64 IL2CPP, Development, High stripping | Build passed |
| Run the IL2CPP executable | Not verified: local process approval timed out twice; explicit permission requested |

The independent fixture has three small tables, dense/missing/sparse IDs, strings,
lists and cross-table references. Its allocation result is not a large-scale
benchmark or a whole-game zero-GC claim. `GC.Alloc` event counts are used; marker
duration is never interpreted as allocated bytes. There is no allocation claim
for IL2CPP until the executable is actually run and calibration passes.

The suite verifies additive/reordered columns, removed or changed required fields,
reference retargeting, legacy format reading, binary reference validation,
prepare/commit isolation, stale/foreign/reused tickets, downgrade rejection,
concurrent publishers/readers, allocation-free captured reads and old-graph
collection. Generated code is compiled, not merely checked as strings.

The runtime assembly has no UnityEngine or sample-game dependency. The compiler
uses the standard Unity Newtonsoft package. Old dynamic consumers remain valid.

## Reproduce From Source

```powershell
powershell -ExecutionPolicy Bypass -File scripts/verify-framework.ps1 -IncludeGameRegression
powershell -ExecutionPolicy Bypass -File scripts/verify-framework-unity.ps1 -Target Editor
powershell -ExecutionPolicy Bypass -File scripts/verify-framework-unity.ps1 -Target IL2CPP
```

The Unity script uses `Tests/UnityConsumer`, installs the packaged tgz, regenerates
the fixture, and checks the process exit code and calibrated allocation report.
Windows IL2CPP requires Unity's Windows IL2CPP module and a supported C++ toolchain.
The script syntax is validated; the new end-to-end script has not yet completed
under the current local execution permission restriction.

## Still Unverified or Out of Scope

Mobile devices, IL2CPP execution, large datasets against a strong typed-DTO
baseline, long-running update stress/peak memory, Lua bridging, remote signing
and delivery, and crash-atomic on-disk installation. No claim that this version
already satisfies an overall interview score of nine is made.
