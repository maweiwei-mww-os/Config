using System;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace GameJson.Editor
{
    public static class ConfigMenus
    {
        [MenuItem("Tools/Game-Json/Compile selected JSON")]
        public static void CompileSelected()
        {
            string path=AssetDatabase.GetAssetPath(Selection.activeObject);
            if(!path.EndsWith(".json",StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("Select a JSON configuration asset.");
            CompileFile(path);AssetDatabase.Refresh();
        }
        public static string CompileFile(string path)
        {
            byte[] bytes=ConfigCompiler.Compile(File.ReadAllText(path));
            CompactConfig.Load(bytes);
            string output=Path.Combine(Path.GetDirectoryName(path),Path.GetFileNameWithoutExtension(path)+"_packed.bytes");
            string temp=output+".tmp";File.WriteAllBytes(temp,bytes);
            if(File.Exists(output))File.Replace(temp,output,null);else File.Move(temp,output);
            Debug.Log("Game-Json compiled "+path+" -> "+output+" ("+bytes.Length+" bytes)");return output;
        }
    }
}
