using System;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;

namespace GameJson
{
    // Reference backend: shared field metadata, row dictionaries, boxed scalars and eager ID indexes.
    public sealed class ObjectConfig : IConfigData
    {
        readonly Dictionary<string, IConfigTable> tables = new Dictionary<string, IConfigTable>(StringComparer.Ordinal);
        public int Version { get; private set; }
        public IConfigTable Table(string name) => tables[name];
        public static ObjectConfig Load(string json)
        {
            var source = SourceDocument.Parse(json);
            var config = new ObjectConfig { Version = source.Version };
            foreach (var t in source.Tables) config.tables.Add(t.Name, new ObjectTable(t));
            return config;
        }
        sealed class ObjectTable : IConfigTable
        {
            readonly string[] names;
            readonly FieldKind[] kinds;
            readonly Dictionary<string, object>[] rows;
            readonly Dictionary<int, int> index = new Dictionary<int, int>();
            public int Count => rows.Length;
            internal ObjectTable(SourceTable source)
            {
                names = new string[source.Fields.Count]; kinds = new FieldKind[names.Length];
                rows = new Dictionary<string, object>[source.Rows.Count];
                foreach (var f in source.Fields) { names[f.Index] = f.Name; kinds[f.Index] = f.Kind; }
                for (int r = 0; r < rows.Length; r++)
                {
                    var row = source.Rows[r]; var data = new Dictionary<string, object>(names.Length, StringComparer.Ordinal);
                    for (int f = 0; f < names.Length; f++)
                    {
                        object value;
                        if (kinds[f] == FieldKind.Int) value = (int)row[f];
                        else if (kinds[f] == FieldKind.String) value = (string)row[f];
                        else { var list = (JArray)row[f]; var a = new int[list.Count]; for (int i = 0; i < a.Length; i++) a[i] = (int)list[i]; value = a; }
                        data.Add(names[f], value);
                    }
                    rows[r] = data; index.Add((int)row[0], r);
                }
            }
            public int Find(int id) => index.TryGetValue(id, out int r) ? r : -1;
            public int Bind(string field, FieldKind kind)
            { int f = Array.IndexOf(names, field); if (f < 0 || kinds[f] != kind) throw new ArgumentException("Missing/wrong field: " + field); return f; }
            public int Int(int row, int field) => (int)rows[row][names[field]];
            public string Text(int row, int field) => (string)rows[row][names[field]];
            public IntList List(int row, int field) { var a = (int[])rows[row][names[field]]; return new IntList(a, 0, a.Length); }
        }
    }
    public sealed class ConfigStore<T> where T : class
    {
        readonly Func<IConfigData, T> bind;
        public T Current { get; private set; }
        public ConfigStore(Func<IConfigData, T> bind) { this.bind = bind ?? throw new ArgumentNullException(nameof(bind)); }
        public bool TryPublish(IConfigData candidate, out string error)
        {
            try { T next = bind(candidate); Current = next; error = null; return true; }
            catch (Exception e) { error = e.Message; return false; }
        }
    }
}
