using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json.Linq;

namespace GameJson
{
    public static class ConfigCompiler
    {
        internal const int Magic = 0x31434a47;
        public static byte[] Compile(string json)
        {
            var source = SourceDocument.Parse(json);
            using var payload = new MemoryStream();
            using (var writer = new BinaryWriter(payload, Encoding.UTF8, true))
            {
                writer.Write(source.Version);
                writer.Write(source.Tables.Count);
                foreach (var table in source.Tables)
                {
                    writer.Write(table.Name);
                    writer.Write(table.Fields.Count);
                    writer.Write(table.Rows.Count);
                    foreach (var field in table.Fields)
                    {
                        writer.Write(field.Name);
                        writer.Write((byte)field.Kind);
                        var strings = new Dictionary<string, int>(StringComparer.Ordinal);
                        var pool = new List<string>();
                        var values = new List<int>();
                        foreach (var row in table.Rows)
                        {
                            var cell = row[field.Index];
                            if (field.Kind == FieldKind.Int) writer.Write((int)cell);
                            else if (field.Kind == FieldKind.String)
                            {
                                string s = (string)cell;
                                if (!strings.TryGetValue(s, out int id))
                                { id = pool.Count; strings.Add(s, id); pool.Add(s); }
                                writer.Write(id);
                            }
                            else
                            {
                                var arr = (JArray)cell;
                                writer.Write(values.Count); writer.Write(arr.Count);
                                foreach (var value in arr) values.Add((int)value);
                            }
                        }
                        if (field.Kind == FieldKind.String)
                        { writer.Write(pool.Count); foreach (string value in pool) writer.Write(value); }
                        if (field.Kind == FieldKind.IntList)
                        { writer.Write(values.Count); foreach (int value in values) writer.Write(value); }
                    }
                }
            }
            byte[] body = payload.ToArray();
            using var sha = SHA256.Create();
            using var output = new MemoryStream();
            using var envelope = new BinaryWriter(output);
            envelope.Write(Magic); envelope.Write(body.Length); envelope.Write(sha.ComputeHash(body)); envelope.Write(body);
            return output.ToArray();
        }
    }

    internal sealed class SourceDocument
    {
        internal int Version;
        internal readonly List<SourceTable> Tables = new List<SourceTable>();
        internal static SourceDocument Parse(string json)
        {
            if (string.IsNullOrEmpty(json) || json.Length > 32 * 1024 * 1024)
                throw new InvalidDataException("JSON is empty or exceeds 32 MiB.");
            var root = JObject.Parse(json);
            var doc = new SourceDocument { Version = ReadInt(root["version"], "version") };
            if (doc.Version < 1) throw new InvalidDataException("version must be positive.");
            var tables = root["tables"] as JArray ?? throw new InvalidDataException("tables must be an array.");
            if (tables.Count < 1 || tables.Count > 128) throw new InvalidDataException("Expected 1..128 tables.");
            var names = new HashSet<string>(StringComparer.Ordinal);
            foreach (JObject item in tables)
            {
                string name = ReadName(item["name"], "table");
                if (!names.Add(name)) throw new InvalidDataException("Duplicate table: " + name);
                var table = new SourceTable { Name = name };
                var fields = item["fields"] as JArray ?? throw new InvalidDataException(name + ": missing fields.");
                var fieldNames = new HashSet<string>(StringComparer.Ordinal);
                if (fields.Count < 1 || fields.Count > 128) throw new InvalidDataException(name + ": expected 1..128 fields.");
                foreach (JObject field in fields)
                {
                    string fieldName = ReadName(field["name"], name);
                    if (!fieldNames.Add(fieldName)) throw new InvalidDataException(name + ": duplicate field " + fieldName);
                    string type = (string)field["type"];
                    FieldKind kind = type == "int" ? FieldKind.Int : type == "string" ? FieldKind.String :
                        type == "int[]" ? FieldKind.IntList : throw new InvalidDataException(name + "." + fieldName + ": unsupported type " + type);
                    table.Fields.Add(new SourceField { Name = fieldName, Kind = kind, Index = table.Fields.Count, Reference = (string)field["ref"] });
                }
                if (table.Fields[0].Name != "id" || table.Fields[0].Kind != FieldKind.Int)
                    throw new InvalidDataException(name + ": first field must be integer id.");
                var rows = item["rows"] as JArray ?? throw new InvalidDataException(name + ": missing rows.");
                if (rows.Count > 1000000) throw new InvalidDataException(name + ": too many rows.");
                foreach (var token in rows)
                {
                    var row = token as JArray ?? throw new InvalidDataException(name + ": row must be array.");
                    if (row.Count != fields.Count) throw new InvalidDataException(name + ": row width mismatch.");
                    int id = ReadInt(row[0], name + ".id");
                    if (id < 0 || !table.Ids.Add(id)) throw new InvalidDataException(name + ": invalid/duplicate id " + id);
                    foreach (var field in table.Fields)
                    {
                        string location = name + "[" + id + "]." + field.Name;
                        var cell = row[field.Index];
                        if (field.Kind == FieldKind.Int) ReadInt(cell, location);
                        else if (field.Kind == FieldKind.String)
                        { if (cell.Type != JTokenType.String) throw new InvalidDataException(location + ": expected string."); }
                        else
                        {
                            if (!(cell is JArray list)) throw new InvalidDataException(location + ": expected int[].");
                            foreach (var v in list) ReadInt(v, location);
                        }
                    }
                    table.Rows.Add(row);
                }
                table.Rows.Sort((a, b) => ((int)a[0]).CompareTo((int)b[0]));
                doc.Tables.Add(table);
            }
            doc.Tables.Sort((a,b) => StringComparer.Ordinal.Compare(a.Name,b.Name));
            foreach (var table in doc.Tables)
                foreach (var field in table.Fields)
                {
                    if (field.Reference == null) continue;
                    var target = doc.Tables.Find(t => t.Name == field.Reference);
                    if (target == null || field.Kind == FieldKind.String)
                        throw new InvalidDataException(table.Name + "." + field.Name + ": invalid reference table " + field.Reference);
                    foreach (var row in table.Rows)
                    {
                        if (field.Kind == FieldKind.Int) CheckReference(target, (int)row[field.Index], table.Name, (int)row[0], field.Name);
                        else foreach (var v in (JArray)row[field.Index]) CheckReference(target, (int)v, table.Name, (int)row[0], field.Name);
                    }
                }
            return doc;
        }
        static void CheckReference(SourceTable target, int id, string table, int row, string field)
        { if (!target.Ids.Contains(id)) throw new InvalidDataException(table + "[" + row + "]." + field + ": missing " + target.Name + "[" + id + "]"); }
        static string ReadName(JToken token, string location)
        {
            string value = token?.Type == JTokenType.String ? (string)token : null;
            if (string.IsNullOrWhiteSpace(value) || value.Length > 128) throw new InvalidDataException(location + ": invalid name.");
            return value;
        }
        internal static int ReadInt(JToken token, string location)
        {
            if (token == null || token.Type != JTokenType.Integer) throw new InvalidDataException(location + ": expected int32.");
            long value = (long)token;
            if (value < int.MinValue || value > int.MaxValue) throw new InvalidDataException(location + ": int32 overflow.");
            return (int)value;
        }
    }
    internal sealed class SourceTable
    {
        internal string Name;
        internal readonly List<SourceField> Fields = new List<SourceField>();
        internal readonly List<JArray> Rows = new List<JArray>();
        internal readonly HashSet<int> Ids = new HashSet<int>();
    }
    internal sealed class SourceField { internal string Name, Reference; internal FieldKind Kind; internal int Index; }
}
