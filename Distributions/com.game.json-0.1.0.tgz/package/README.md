# Game-Json Compact Config

Unity 2022.3 package. No dependency on Dice Town, UT-RS, xLua or a service.
Uses the standard `com.unity.nuget.newtonsoft-json` dependency, not a vendored assembly.

## Install and use

Install `com.game.json-0.1.0.tgz` using Package Manager > Add package from tarball.
Alternatively select this directory's `package.json` with Add package from disk.
Import the Quick Start sample. Select its `rewards.json`, then run
Tools > Game-Json > Compile selected JSON. The adjacent `rewards_packed.bytes`
is the runtime artifact. Attach ReadConfigExample to a GameObject and assign it.

```csharp
var config = CompactConfig.Load(packedBytes);
var rewards = config.Table("Reward");
int coins = rewards.Bind("coins", FieldKind.Int); // Bind once.
int row = rewards.Find(1);
if (row >= 0) { int value = rewards.Int(row, coins); }
```

Source JSON has a positive `version` and `tables`. Each table has `name`, `fields`,
and array-shaped `rows`. The first field must be `id:int`; IDs are unique and
nonnegative. Supported field types: `int`, `string`, `int[]`. Add `ref:"OtherTable"`
to an integer or integer-list field for cross-table ID validation. Mixed nested
records are normalized to referenced tables, not arbitrary JSON object trees.

The compiler validates types, overflow, row width, duplicates and references;
sorts tables and rows deterministically; and writes a checksummed binary file.
The loader validates before exposing data, creates column arrays, uses a bounded
dense index or binary search, and shares strings within a column. No GCHandle,
native allocation, unsafe code, runtime reflection for field access or global
string interning. This is column-array storage, not memory mapping or zero-copy loading.

`IntList` is a read-only value view. No mutable arrays are exposed. Bind field
slots once against their owning table, then read by row. Slots belong to that
table; do not reuse them for a different schema. String reads return strings
created during loading. Loading allocates; normal warmed reads do not require
new managed objects. Missing IDs return -1; invalid fields/types throw.

`ConfigStore<T>` binds and validates a complete candidate before replacing
Current. Bind must be side-effect free. This is a main-thread synchronous API,
not a concurrent publication service. Keep an old reference to finish existing
work, or capture the needed settlement values as the sample game does. Managed
GC releases unreachable old versions. Publication is in-memory, not a
crash-atomic multi-file installer. The hash detects corruption, not authenticity.

The ObjectConfig backend is a conventional row-dictionary JSON reference
implementation with an eager ID index. It is NOT a copy of the original
Game-Json CompactConfig implementation. Both backends can have allocation-free
hot reads; avoiding allocations alone is not a reason to claim one is superior.

Tested targets and current performance evidence are in the containing game's
README and Artifacts. No claim of IL2CPP, Android, iOS, WebGL or Lua validation
is implied by passing .NET or Windows Mono tests.
