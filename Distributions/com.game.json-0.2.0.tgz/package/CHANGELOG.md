# Changelog

## 0.2.0

- Generate typed read-only table/row APIs and allocation-free struct enumerators.
- Bind typed column views, preserving the dynamic API and reference backend.
- Preserve cross-table reference metadata in GJC2; validate references in the
  binary loader and generated contract. Read legacy GJC1 with the dynamic API.
- Add compatible additive schema changes and explicit breaking-change rejection.
- Prepare and atomically commit versioned snapshots with stale/foreign/reused
  candidate detection, opt-in increasing revisions and lock-free captured reads.
- Add Typed Snapshots sample, editor generation command and offline build tool.
- Add independent framework tests for compatibility, concurrency, allocations and
  lifetime. This release does not implement remote delivery or disk transactions.

## 0.1.0

- Initial column-array configuration, compiler, dynamic binding and quick start.
