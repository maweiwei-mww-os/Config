using System;

namespace GameJson
{
    public static class ConfigContract
    {
        public static void RequireReference(IConfigData data, string table, string field, string expectedTarget)
        {
            if (!(data is IConfigSchema schema) || !schema.HasReferenceMetadata)
                throw new System.IO.InvalidDataException(table + "." + field + ": reference metadata unavailable; recompile with Game-Json 0.2 or later.");
            string actual = schema.ReferenceTarget(table, field);
            if (!string.Equals(actual, expectedTarget, StringComparison.Ordinal))
                throw new System.IO.InvalidDataException(table + "." + field + ": expected reference " + expectedTarget + ", received " + (actual ?? "none"));
        }
    }
    // Optional fast path: generated code can also bind any existing IConfigTable implementation.
    public interface IConfigColumnSource
    {
        IntColumn BindInt(string name);
        StringColumn BindString(string name);
        IntListColumn BindIntList(string name);
    }
    public static class ConfigColumns
    {
        public static IntColumn Int(IConfigTable table, string name) => table is IConfigColumnSource columns
            ? columns.BindInt(name) : new IntColumn(table, table.Bind(name, FieldKind.Int));
        public static StringColumn String(IConfigTable table, string name) => table is IConfigColumnSource columns
            ? columns.BindString(name) : new StringColumn(table, table.Bind(name, FieldKind.String));
        public static IntListColumn List(IConfigTable table, string name) => table is IConfigColumnSource columns
            ? columns.BindIntList(name) : new IntListColumn(table, table.Bind(name, FieldKind.IntList));
    }
    public readonly struct IntColumn
    {
        readonly int[] values;
        readonly IConfigTable fallback;
        readonly int field;
        internal IntColumn(int[] values) { this.values = values; fallback = null; field = 0; }
        internal IntColumn(IConfigTable table, int field) { values = null; fallback = table; this.field = field; }
        public int this[int row] => values != null ? values[row] : fallback.Int(row, field);
    }
    public readonly struct StringColumn
    {
        readonly int[] indices;
        readonly string[] strings;
        readonly IConfigTable fallback;
        readonly int field;
        internal StringColumn(int[] indices, string[] strings) { this.indices = indices; this.strings = strings; fallback = null; field = 0; }
        internal StringColumn(IConfigTable table, int field) { indices = null; strings = null; fallback = table; this.field = field; }
        public string this[int row] => indices != null ? strings[indices[row]] : fallback.Text(row, field);
    }
    public readonly struct IntListColumn
    {
        readonly int[] slices, items;
        readonly IConfigTable fallback;
        readonly int field;
        internal IntListColumn(int[] slices, int[] items) { this.slices = slices; this.items = items; fallback = null; field = 0; }
        internal IntListColumn(IConfigTable table, int field) { slices = null; items = null; fallback = table; this.field = field; }
        public IntList this[int row]
        {
            get {
                if (slices == null) return fallback.List(row, field);
                if ((uint)row >= (uint)(slices.Length / 2)) throw new ArgumentOutOfRangeException(nameof(row));
                return new IntList(items, slices[row * 2], slices[row * 2 + 1]);
            }
        }
    }
}
