# Verification - 0.3.1

Date: 2026-10-09. Observed Windows results, not a platform-wide guarantee.

| Check | Result |
| --- | --- |
| Independent .NET 8 framework suite | 30 passed |
| Existing game consumer regression | 28 passed |
| Install tgz into independent Unity project | Passed |
| Unity 2022.3.60f1c1 Windows x64 IL2CPP | Built and executed successfully |
| Build configuration | Development, High managed stripping |
| Generated fixture assembly | Separate assembly, no linker preservation directive |
| Typed fields, references, row/list iteration, Capture | 200,000 iterations, 0 allocation events |
| Allocation calibration | Empty: 0 events; new 4 KB array: 1 event |
| Typed DTO benchmark | 3,000 / 30,000 / 300,000 records; four backends; five workloads |
| Benchmark read allocations | Zero for every tested backend/workload/scale |
| Lifetime and fault tests | 1000 updates, retained old snapshot, retired graph collection, failed loads |
| Concurrent publication | Multiple readers, competing commits, cancellation races, stale/foreign/reused tickets |

## IL2CPP Measurements

Three tables with 100,000 records each; median warm in-process times. Input
buffers are already loaded and excluded from retained managed graph estimates.
1 MiB = 1,048,576 bytes. These are not process peak-memory or FPS measurements.

| Metric | Compact FastLookup | Typed DTO + Dictionary | DTO + pooled strings | Compact small index |
| --- | ---: | ---: | ---: | ---: |
| Retained managed MiB | 9.37 | 39.48 | 35.40 | 7.29 |
| Load and validate ms | 115.26 | 507.66 | 522.57 | 114.14 |
| Dense mixed read ns/op | 282.62 | 580.43 | 566.17 | 283.74 |
| Sparse hit ns/op | 128.96 | 124.44 | 119.98 | 308.49 |
| Missing ID ns/op | 43.53 | 33.13 | 34.42 | 249.74 |
| Row scan ns/element | 20.51 | 4.80 | 4.37 | 20.32 |
| Numeric column scan ns/element | 0.70 | 4.14 | 2.96 | 0.65 |
| Warm read allocated bytes | 0 | 0 | 0 | 0 |

The DTO baseline uses Unity JsonUtility, typed row arrays and prebuilt indexes,
not the weaker ObjectConfig dictionary-per-row baseline. Both baselines validate
IDs/references; compact loading additionally checks SHA256 and binds the generated
contract. Equal logical values and query checksums are required. JSON shapes
differ: source row-array JSON is 10,009,787 UTF-8 bytes; DTO JSON is 18,709,305;
compiled binary is 7,613,076 bytes. Offline compilation is excluded from runtime
loading, not claimed to be free. .NET reports record its compilation time.

Load timing uses five interleaved rounds; queries use seven. Reports preserve
minimum/median/maximum, not just one favorable sample. Allocation recording runs
separately from timing. Unity uses GC.Alloc event counts; marker duration is
not an allocated byte count. Load allocated bytes are unavailable (-1), while
load event counts are reported. Calibrated zero events supports zero allocation
on the tested synchronous read path. .NET uses a byte counter and is reported
separately; it uses Newtonsoft.Json for its DTO baseline.

Important negative results: small-table mixed lookup can be slower than DTOs;
sparse/missing lookups are not universally faster. IL2CPP row scanning has
significant wrapper overhead. Use primitive ReadOnlySpan column access for bulk
statistics; the original row-scan results remain visible. FastLookup spends
about 2.1 MiB more than binary-search indexing at this scale. String pooling alone
does not account for the full retained-memory difference.

## Reproduce

From the source checkout:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/verify-framework.ps1 -IncludeGameRegression
dotnet run --project Tests/BenchmarkTests.csproj -c Release
powershell -ExecutionPolicy Bypass -File scripts/pack-framework.ps1
powershell -ExecutionPolicy Bypass -File scripts/verify-framework-unity.ps1 -Target IL2CPP -Benchmark
powershell -ExecutionPolicy Bypass -File scripts/run-framework-benchmark.ps1
```

The final command runs the existing executable without launching the Editor and
prints a table. Unity build verification needs the Windows IL2CPP module, an
appropriate C++ toolchain, a valid Unity license and sufficient temporary disk
space. The full script was executed, not merely syntax-checked. The standalone
benchmark script also completed independently. Frozen raw reports and source
hashes are retained in `Tests/Evidence/0.3.1`; working logs are in `Artifacts`.

## Boundaries

Loading, binding, publication and error paths allocate. A captured old row keeps
its graph alive; multiple versions can coexist, so updates need memory headroom.
The 1000-update test verifies reachability/reclamation, not an hours-long mobile
soak or a precise peak-memory bound. Checksum is corruption detection, not
authentication. Publication is in-memory, not crash-atomic multi-file delivery.

Android/iOS hardware, Release-player allocation instrumentation, Lua bridging,
remote signing/download and arbitrary nested JSON are not claimed. Generated
access does not use runtime reflection; the benchmark's DTO/report reflection
is preserved in its separate consumer assembly. Interview scores remain human
judgments; this report supplies reproducible engineering evidence, not a score
guarantee.
